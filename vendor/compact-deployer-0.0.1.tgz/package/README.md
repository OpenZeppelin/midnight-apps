# @openzeppelin/compact-deployer

```bash
compact-deploy Token --network local
```

> **Status: developer-preview, testnet only.** Verified on local devnet + preview. Preprod blocked ([Known issues](#known-issues-may-2026)). Mainnet unsupported — unaudited, no hardware signer, no multisig, no tx retry, no upgrade tooling. See [Roadmap](#roadmap--todo).

## Quick start

1. Compile your contract with `compact-compiler` so artifacts land under `src/artifacts/<Name>/`.
2. Drop a `compact.toml` at your repo root (see [Sample config](#sample-config)).
3. Generate a signing key per contract: `head -c 32 /dev/urandom | xxd -p -c 32 > deploy/Token.signingkey`.
4. Run:
   ```bash
   compact-deploy Token --network local
   ```

The deploy result lands in `deployments/compact/<network>.json`.

## CLI

```
compact-deploy <Contract>
  --network <name>          required unless [profile].default_network is set
  --config <path>           default: walk up from CWD for compact.toml
  --seed-file <path>        seed override (raw hex or BIP39 mnemonic, one line)
  --proof-server <url>      override [networks.X].proof_server
  --sync-timeout <seconds>  max wait for wallet to reach chain tip (default 600)
  --no-cache                ignore on-disk wallet-state cache; force fresh sync
  --dry-run                 load, validate, build providers, log plan, DO NOT submit
  --json                    single JSON object on stdout (machine-readable)
  -v, --verbose             pino debug logs to .compact/logs/<timestamp>.log
  -h, --help                --version
```

Exit codes: `0` ok · `2` config error · `3` wallet error · `4` provider unreachable · `5` deploy tx failed · `1` unexpected.

## Deploying to real networks (preprod, preview, testnet)

> Preprod is blocked on an upstream wallet-SDK bug — use `--network preview`. See [Known issues](#known-issues-may-2026).

- **First sync is slow** (~3 min on preview, 30–60 min on preprod from genesis). Cache makes reruns near-instant.
- **Bump sync timeout**: `--sync-timeout 3600` (default 10 min).
- **Bump Node heap** for long-history chains: `NODE_OPTIONS="--max-old-space-size=8192"`.
- **Seed source**: `--seed-file`, `MN_DEPLOYER_SEED`, or `[wallet].keystore`. The `wallet = { source = "local" }` shorthand is dev-preset only.

## Wallet cache

After each successful sync the deployer writes `<cwd>/.states/<network>-<seed-hash>-<kind>.gz` (one file per shielded / dust sub-wallet). Next run restores from it instead of re-syncing from genesis.

- Contents: gzipped sub-wallet state (UTXOs, checkpoint). No private keys — re-derived from seed each run.
- Keyed by SHA-256(seed) + network ID, so `local` vs `preprod` keep separate caches.
- Bust it: `--no-cache` (force fresh) or `rm -rf .states/`. Auto-falls-back on corrupt or version-mismatched files.
- Best-effort writes; never block a deploy. Concurrent runs against the same seed race — don't.
- `.states/` is gitignored.

## Wallet seed resolution

Precedence, first non-null wins:

1. `--seed-file <path>`
2. `MN_DEPLOYER_SEED` env var (hex or BIP39 mnemonic)
3. `[wallet].keystore` (encrypted JSON, passphrase prompted)
4. `--network local` only: built-in prefunded standalone seed at `[networks.local].wallet.index` (0..3)

## Sample config

```toml
[profile]
default_network = "local"
artifacts_dir   = "src/artifacts"
deployments_dir = "deployments/compact"

# ---------- Networks ----------
[networks.local]
network_id   = "undeployed"
indexer      = "http://127.0.0.1:8088/api/v3/graphql"
indexer_ws   = "ws://127.0.0.1:8088/api/v3/graphql/ws"
node         = "http://127.0.0.1:9944"
node_ws      = "ws://127.0.0.1:9944"
proof_server = "http://127.0.0.1:6300"
wallet       = { source = "local", index = 0 }

[networks.preview]
network_id   = "preview"
indexer      = "https://indexer.preview.midnight.network/api/v4/graphql"
indexer_ws   = "wss://indexer.preview.midnight.network/api/v4/graphql/ws"
node         = "https://rpc.preview.midnight.network"
node_ws      = "wss://rpc.preview.midnight.network"
proof_server = "auto"
explorer     = "https://preview.midnightexplorer.com"

[networks.preprod]
network_id   = "preprod"
indexer      = "https://indexer.preprod.midnight.network/api/v4/graphql"
indexer_ws   = "wss://indexer.preprod.midnight.network/api/v4/graphql/ws"
node         = "https://rpc.preprod.midnight.network"
node_ws      = "wss://rpc.preprod.midnight.network"
proof_server = "auto"
explorer     = "https://preprod.midnightexplorer.com"

# ---------- Wallet (non-local) ----------
[wallet]
keystore = "./deployer.keystore.json"

# ---------- Contracts ----------
[contracts.Token]
artifact           = "src/artifacts/Token/Token"
private_state_id   = "tokenPrivateState"
init_private_state = { file = "./deploy/Token.private-state.json" }
args               = ["MyToken", "MTK", 18]
signing_key_file   = "./deploy/Token.signingkey"

[contracts.Vault]
artifact         = "src/artifacts/Vault/Vault"
args             = []
signing_key_file = "./deploy/Vault.signingkey"
```

`proof_server`: a URL pins the server; `"auto"` spawns a `testcontainers`-managed proof-server container for the duration of the deploy; omitting it falls back to the env var `PROOF_SERVER_PORT` then to `http://127.0.0.1:6300`.

## Keystore format

`compact-deploy` reads/writes a JSON keystore with the Ethereum V3 shape (scrypt + AES-128-CTR) but with `version: "midnight-1"` so other tooling does not silently mis-read it as an Ethereum key. The encrypted secret is a 32-byte Midnight wallet seed (hex).

## Known issues (May 2026)

### Preprod blocked: `midnight:event[v9]` dust crash
Dust sync crashes at event id **565,975** — a `DustSpendProcessed` with the `midnight:event[v9]:` prefix the wallet SDK can't deserialize. Reproduced on the support-matrix stack (`ledger-v8@8.0.3`, `wallet-sdk-dust-wallet@3.0.0`, `wallet-sdk-facade@3.0.0`).
Reported in the [Midnight dev Discord (May 22)](https://discord.com/channels/1165826384975908924/1209887476290682910/1507122046440706108). No GitHub issue yet — file against [midnight-indexer](https://github.com/midnightntwrk/midnight-indexer/issues/new) (v9 producer) and/or [midnight-wallet](https://github.com/midnightntwrk/midnight-wallet/issues/new) (consumer).
**Workaround:** `--network preview`.

### Faucet is manual
The deployer never hits a faucet — fund the wallet's `unshielded` address (logged at startup) via the official Midnight faucet site or Discord bot before running.

### Dust fee overhead default breaks faucet wallets
testkit-js default `additionalFeeOverhead` is `5e20` vs a faucet wallet's `~3e15` dust → `Insufficient Funds: could not balance dust`. Deployer overrides to `5e14` for non-mainnet. Library users constructing their own provider must mirror this.

### Long-history dust sync exhausts default Node heap
Use `NODE_OPTIONS="--max-old-space-size=16384"` for first sync. Cache fixes subsequent runs.

## Programmatic API

```ts
import { deploy } from "@openzeppelin/compact-deployer";

const result = await deploy({
  contract: "Token",
  network: "local",
  configPath: "./compact.toml",
});
console.log(result.address);
```

## Roadmap / TODO

Rough priority order. Each open item is a reason not to trust the deployer for mainnet today.

### Security & key management
- [ ] Hardware-signer support (Ledger / Trezor / external-signer RPC).
- [ ] Multisig deploy flow: unsigned intent → N-of-M sigs → submit.
- [ ] Derive contract signing keys from the wallet seed (HKDF + contract name) so the seed alone is sufficient backup.
- [ ] Audit + harden the encrypted `[wallet].keystore` format and prompt UX.
- [ ] Redact seeds + signing keys from logs and stack traces.

### Reliability & operations
- [ ] Tx retry / idempotency: a deploy that fails mid-submit shouldn't need manual cleanup.
- [ ] Nonce / sequence management for concurrent invocations.
- [ ] Resume-from-pending: detect an already-submitted deploy and watch it instead of resubmitting.
- [ ] Fail-fast health checks for proof server + indexer URLs.
- [ ] Structured telemetry / spans for deploy phases.

### Network coverage
- [ ] **Mainnet end-to-end verification.** Blocked: mainnet not live, no faucet, needs real value.
- [ ] Fix preprod — upstream `midnight:event[v9]` bug. Out of our hands.
- [ ] Re-tune `additionalFeeOverhead` per network once mainnet dust economics are known.
- [ ] Add an opt-in `--faucet` flag once testkit-js's faucet URLs are no longer stale, so users don't have to leave the CLI to fund a fresh wallet.

### Contract lifecycle
- [ ] Upgrade / migration tooling — today only fresh deploys exist.
- [ ] `compact-deploy diff` against the last recorded deploy (artifact hash, args, witnesses, key).
- [ ] Post-deploy verification: on-chain bytecode/address matches local artifacts.
- [ ] Multi-contract orchestration: deploy a graph with cross-refs (e.g. Lunarswap Factory + Router + Pair).

### Developer experience
- [ ] Richer dry-run output: resolved args, predicted address, fee estimate.
- [ ] One-shot sync status (`dust applied=X/maxId=Y, ETA Zm`) instead of polling lines.
- [ ] Optional TUI mode (Ink / blessed) for cleaner progress.
- [ ] Sample workflows: local seed data, integration test against deployed contract.
